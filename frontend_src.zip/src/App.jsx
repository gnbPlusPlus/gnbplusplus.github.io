import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home.jsx';
import PetDetail from './pages/PetDetail.jsx';
import './App.css';

// Most of the app's functionality is handled by the Home page, but basic routing is set up here
function App() {
  return (
    // Resource used: https://www.w3schools.com/react/react_router.asp
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/pet/:id" element={<PetDetail />} />
    </Routes>
  );
}

export default App;
